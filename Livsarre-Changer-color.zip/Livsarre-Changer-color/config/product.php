<?php

return [
    'licenseCodeCheckerUrl' => 'https://support.inilabs.net',
    'officialSite'          => 'https://inilabs.net',
    'loginUrl'              => 'https://inilabs.net/login',
    'activeLicense'         => 'https://inilabs.net/active-license',
    'itemId'                => '45845092',
    'version'               => '1.2'
];
