<?php

namespace App\Enums;

interface SwitchBox
{
    const ON  = 5;
    const OFF = 10;
}
