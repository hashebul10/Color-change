<?php

namespace App\Enums;

interface IsAdvance
{
    const YES          = 5;
    const NO           = 10;
}
