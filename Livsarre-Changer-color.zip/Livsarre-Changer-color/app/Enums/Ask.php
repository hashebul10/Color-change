<?php

namespace App\Enums;

interface Ask
{
    const YES = 5;
    const NO  = 10;
}
