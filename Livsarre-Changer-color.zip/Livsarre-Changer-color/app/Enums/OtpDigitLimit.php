<?php

namespace App\Enums;

interface OtpDigitLimit
{
    const FOUR  = 4;
    const SIX   = 6;
    const EIGHT = 8;
}
