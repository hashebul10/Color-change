<?php

namespace App\Enums;

interface MenuType
{
     const BACKEND  = 1;
     const FRONTEND = 2;
}


