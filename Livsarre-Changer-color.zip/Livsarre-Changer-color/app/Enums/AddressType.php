<?php
namespace App\Enums;

interface AddressType
{
    const HOME  = 5;
    const WORK  = 10;
    const OTHER = 15;
}
