<?php

namespace App\Enums;

interface InputType
{
    const TEXT   = 5;
    const SELECT = 10;
}
